package de.mm20.launcher2.ui.launcher.search.alphabetic

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import de.mm20.launcher2.search.SavableSearchable
import de.mm20.launcher2.ui.R
import de.mm20.launcher2.ui.launcher.search.common.grid.GridItem

/** Barra lateral permanente de favoritos: só ícones; o toque em "»" expande para mostrar os nomes. */
@Composable
fun FavoritesSidebar(
    favorites: List<SavableSearchable>,
    expanded: Boolean,
    onToggleExpanded: () -> Unit,
    onEdit: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val toggleDescription = stringResource(R.string.alphabetic_expand_favorites)
    val editDescription = stringResource(R.string.alphabetic_edit_favorites)
    Column(
        modifier = modifier
            .fillMaxHeight()
            .width(if (expanded) 112.dp else 64.dp)
            .animateContentSize(),
    ) {
        Row {
            Text(
                text = if (expanded) "\u00ab" else "\u00bb",
                modifier = Modifier
                    .semantics { contentDescription = toggleDescription }
                    .clickable { onToggleExpanded() }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            )
            if (expanded) {
                Text(
                    text = "+",
                    modifier = Modifier
                        .semantics { contentDescription = editDescription }
                        .clickable { onEdit() }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                )
            }
        }
        LazyColumn {
            items(favorites, key = { it.key }) {
                GridItem(
                    modifier = Modifier.padding(vertical = 4.dp),
                    item = it,
                    showLabels = expanded,
                )
            }
            if (!expanded) {
                item(key = "edit") {
                    Text(
                        text = "+",
                        modifier = Modifier
                            .semantics { contentDescription = editDescription }
                            .clickable { onEdit() }
                            .padding(horizontal = 24.dp, vertical = 12.dp),
                    )
                }
            }
        }
    }
}
