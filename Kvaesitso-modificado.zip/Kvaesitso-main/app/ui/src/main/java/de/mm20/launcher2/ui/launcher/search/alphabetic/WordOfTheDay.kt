package de.mm20.launcher2.ui.launcher.search.alphabetic

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import java.time.LocalDate

private data class DailyWord(val word: String, val meaning: String, val example: String)

// Conteúdo local inicial (sem dependências externas). Um item por dia, em rotação.
private val words = listOf(
    DailyWord("Serendipidade", "Descoberta feliz feita por acaso.", "Achei o livro por serendipidade."),
    DailyWord("Efêmero", "Que dura pouco tempo.", "A fama pode ser efêmera."),
    DailyWord("Resiliência", "Capacidade de se recuperar de adversidades.", "Sua resiliência inspira a equipe."),
    DailyWord("Sublime", "Que inspira admiração pela grandeza.", "O pôr do sol estava sublime."),
    DailyWord("Perspicaz", "Que percebe com agudeza e rapidez.", "Fez uma observação perspicaz."),
    DailyWord("Lacônico", "Que fala ou escreve de forma breve.", "Respondeu de modo lacônico."),
    DailyWord("Eloquente", "Que se expressa com fluência e força.", "Um discurso eloquente."),
    DailyWord("Ubíquo", "Que está em toda parte ao mesmo tempo.", "O celular tornou-se ubíquo."),
    DailyWord("Quimera", "Fantasia; ideia sem possibilidade de realização.", "Perseguia uma quimera."),
    DailyWord("Clemência", "Disposição para perdoar com bondade.", "Pediu clemência ao juiz."),
    DailyWord("Anseio", "Desejo intenso e persistente.", "Tinha o anseio de viajar."),
    DailyWord("Fugaz", "Que passa depressa.", "Um instante fugaz de silêncio."),
    DailyWord("Pertinaz", "Que persiste com firmeza.", "Uma chuva pertinaz."),
    DailyWord("Ínclito", "Ilustre, famoso.", "O ínclito professor chegou."),
    DailyWord("Mister", "Necessidade; ocupação.", "É mister agir com cuidado."),
    DailyWord("Empatia", "Capacidade de se colocar no lugar do outro.", "Agiu com empatia."),
    DailyWord("Vicissitude", "Mudança de fortuna; altos e baixos.", "Enfrentou as vicissitudes da vida."),
    DailyWord("Alvorecer", "Começo do dia; início de algo.", "O alvorecer trouxe esperança."),
    DailyWord("Tenaz", "Que não desiste; firme.", "Um esforço tenaz."),
    DailyWord("Cândido", "Puro, ingênuo, sincero.", "Deu um sorriso cândido."),
)

/** Único componente: palavra, significado e frase de exemplo. Discreto; usa as cores do tema. */
@Composable
fun WordOfTheDay(modifier: Modifier = Modifier) {
    val word = remember { words[LocalDate.now().dayOfYear % words.size] }
    Column(modifier = modifier) {
        Text(
            text = word.word,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
        )
        Text(
            text = word.meaning,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = "\u201c${word.example}\u201d",
            style = MaterialTheme.typography.bodySmall,
            fontStyle = FontStyle.Italic,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
