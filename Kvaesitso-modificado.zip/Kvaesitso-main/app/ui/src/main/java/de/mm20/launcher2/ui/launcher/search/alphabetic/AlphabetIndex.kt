package de.mm20.launcher2.ui.launcher.search.alphabetic

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Índice vertical. O primeiro item (estrela) limpa o filtro; as demais entradas são as letras
 * que realmente existem na lista de aplicativos.
 */
@Composable
fun AlphabetIndex(
    letters: List<String>,
    selected: String?,
    onSelect: (String?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val entries: List<String?> = listOf(null) + letters
    var height by remember { mutableIntStateOf(1) }

    fun indexAt(y: Float): Int =
        ((y / height) * entries.size).toInt().coerceIn(0, entries.size - 1)

    Column(
        modifier = modifier
            .width(28.dp)
            .fillMaxHeight()
            .onSizeChanged { height = it.height.coerceAtLeast(1) }
            .pointerInput(entries) {
                detectTapGestures { onSelect(entries[indexAt(it.y)]) }
            }
            .pointerInput(entries) {
                detectVerticalDragGestures { change, _ ->
                    onSelect(entries[indexAt(change.position.y)])
                }
            },
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        for (entry in entries) {
            val active = entry == selected
            Text(
                text = entry ?: "\u2605",
                fontSize = 12.sp,
                fontWeight = if (active) FontWeight.Black else FontWeight.Medium,
                color = if (active) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(vertical = 0.dp),
            )
        }
    }
}
