package de.mm20.launcher2.ui.launcher.widgets.clock.clocks

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import de.mm20.launcher2.ui.locals.LocalDarkTheme
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
private fun weekdayClockColor(useThemeColor: Boolean, darkColors: Boolean): Color {
    return if (useThemeColor) {
        if (!darkColors) {
            if (LocalDarkTheme.current) MaterialTheme.colorScheme.onPrimaryContainer
            else MaterialTheme.colorScheme.primaryContainer
        } else {
            if (LocalDarkTheme.current) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.primary
        }
    } else {
        LocalContentColor.current
    }
}

private fun timePattern(twentyFourHours: Boolean) = if (twentyFourHours) "HH:mm" else "hh:mm"

/**
 * Estilo 1: dia da semana abreviado em destaque, com data e horário integrados na mesma composição.
 */
@Composable
fun WeekdayClock1(
    time: Long,
    compact: Boolean,
    twentyFourHours: Boolean,
    useThemeColor: Boolean,
    darkColors: Boolean,
) {
    val color = weekdayClockColor(useThemeColor, darkColors)
    val locale = Locale.getDefault()
    val weekday = SimpleDateFormat("EEE", locale).format(time).trimEnd('.').uppercase(locale)
    val date = SimpleDateFormat("d MMM", locale).format(time)
    val clock = SimpleDateFormat(timePattern(twentyFourHours), locale).format(time)

    if (compact) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = weekday,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Black,
                    color = color,
                ),
            )
            Text(
                text = "$date · $clock",
                style = MaterialTheme.typography.titleMedium.copy(color = color),
            )
        }
    } else {
        Column(verticalArrangement = Arrangement.spacedBy((-8).dp)) {
            Text(
                text = weekday,
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 72.sp,
                    fontWeight = FontWeight.Black,
                    color = color,
                ),
            )
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    text = clock,
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.Light,
                        fontFeatureSettings = "tnum",
                        color = color,
                    ),
                )
                Text(
                    text = date,
                    style = MaterialTheme.typography.titleMedium.copy(color = color),
                )
            }
        }
    }
}

/**
 * Estilo 2: dia da semana por extenso em destaque; data e horário menores, empilhados abaixo.
 */
@Composable
fun WeekdayClock2(
    time: Long,
    compact: Boolean,
    twentyFourHours: Boolean,
    useThemeColor: Boolean,
    darkColors: Boolean,
) {
    val color = weekdayClockColor(useThemeColor, darkColors)
    val locale = Locale.getDefault()
    val weekday = SimpleDateFormat("EEEE", locale).format(time)
        .replaceFirstChar { it.titlecase(locale) }
    val date = SimpleDateFormat("d MMMM", locale).format(time)
    val clock = SimpleDateFormat(timePattern(twentyFourHours), locale).format(time)

    Column {
        Text(
            text = weekday,
            style = MaterialTheme.typography.displaySmall.copy(
                fontSize = if (compact) 28.sp else 44.sp,
                fontWeight = FontWeight.Bold,
                color = color,
            ),
        )
        Text(
            text = "$date  $clock",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Normal,
                fontFeatureSettings = "tnum",
                color = color,
            ),
        )
    }
}
