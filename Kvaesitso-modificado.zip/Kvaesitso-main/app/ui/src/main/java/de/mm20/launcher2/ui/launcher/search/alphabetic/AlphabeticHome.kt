package de.mm20.launcher2.ui.launcher.search.alphabetic

import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import de.mm20.launcher2.notifications.NotificationRepository
import de.mm20.launcher2.preferences.ui.ClockWidgetSettings
import de.mm20.launcher2.search.Application
import de.mm20.launcher2.search.SavableSearchable
import de.mm20.launcher2.ui.R
import de.mm20.launcher2.ui.launcher.search.common.list.ListItem
import de.mm20.launcher2.ui.launcher.sheets.LocalBottomSheetManager
import de.mm20.launcher2.ui.launcher.widgets.clock.Clock
import org.koin.compose.koinInject
import java.text.Normalizer

private fun normalizedLabel(label: String): String =
    Normalizer.normalize(label.trim(), Normalizer.Form.NFD).lowercase()

private fun initialOf(label: String): String {
    val c = Normalizer.normalize(label.trim(), Normalizer.Form.NFD).firstOrNull()
    return if (c != null && c.isLetter()) c.uppercaseChar().toString() else "#"
}

/**
 * Home alfabético: relógio e palavra do dia no topo; favoritos à esquerda; lista de aplicativos
 * no centro; índice A-Z à direita. Reaproveita ListItem, GridItem, Clock, FavoritesVM e a lista
 * de aplicativos do SearchVM (que já se atualiza com instalações/desinstalações).
 */
@Composable
fun AlphabeticHome(
    apps: List<Application>,
    favorites: List<SavableSearchable>,
    paddingValues: PaddingValues,
    modifier: Modifier = Modifier,
) {
    val vm: AlphabeticHomeVM = viewModel()
    val context = LocalContext.current
    val sheetManager = LocalBottomSheetManager.current

    val sidebarExpanded by vm.sidebarExpanded.collectAsState(false)
    val showWord by vm.wordOfTheDay.collectAsState(true)
    val notificationsEnabled by vm.notifications.collectAsState(true)
    val hideContent by vm.hideNotificationContent.collectAsState(false)
    val mutedApps by vm.mutedApps.collectAsState(emptySet())

    val clockSettings: ClockWidgetSettings = koinInject()
    val clockStyle by clockSettings.clockStyle.collectAsState(null)

    val notificationRepository: NotificationRepository = koinInject()
    val allNotifications by notificationRepository.notifications.collectAsState(emptyList())
    val notificationsByPackage by remember {
        derivedStateOf {
            allNotifications.filter { !it.isGroupSummary }.groupBy { it.packageName }
        }
    }

    val appList = apps.toList()
    val sorted = remember(appList) { appList.sortedBy { normalizedLabel(it.label) } }
    val letters = remember(sorted) { sorted.map { initialOf(it.label) }.distinct().sorted() }

    var selectedLetter by rememberSaveable { mutableStateOf<String?>(null) }
    // Se a letra selecionada deixou de existir (app desinstalado), volta a mostrar tudo.
    val activeLetter = selectedLetter?.takeIf { it in letters }
    val visible = remember(sorted, activeLetter) {
        if (activeLetter == null) sorted else sorted.filter { initialOf(it.label) == activeLetter }
    }
    var detailsKey by remember { mutableStateOf<String?>(null) }

    Column(modifier = modifier.fillMaxSize().padding(paddingValues)) {
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Clock(clockStyle, false, false)
            if (showWord) {
                WordOfTheDay(modifier = Modifier.padding(top = 8.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = {
                    try {
                        context.startActivity(
                            Intent.createChooser(
                                Intent(Intent.ACTION_SET_WALLPAPER),
                                context.getString(R.string.alphabetic_wallpaper)
                            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (e: ActivityNotFoundException) {
                        // Sem seletor de wallpaper no dispositivo: nada a fazer.
                    }
                }) { Text(stringResource(R.string.alphabetic_wallpaper)) }
                if (mutedApps.isNotEmpty()) {
                    TextButton(onClick = { vm.restoreMutedApps() }) {
                        Text(stringResource(R.string.alphabetic_notification_restore))
                    }
                }
            }
        }

        Row(modifier = Modifier.weight(1f)) {
            FavoritesSidebar(
                favorites = favorites,
                expanded = sidebarExpanded,
                onToggleExpanded = { vm.setSidebarExpanded(!sidebarExpanded) },
                onEdit = { sheetManager.showEditFavoritesSheet() },
            )
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(visible, key = { it.key }) { app ->
                    Column {
                        ListItem(
                            item = app,
                            showDetails = detailsKey == app.key,
                            onShowDetails = { detailsKey = if (it) app.key else null },
                        )
                        val pkg = app.componentName.packageName
                        val notifications = notificationsByPackage[pkg]
                        if (notificationsEnabled && pkg !in mutedApps &&
                            !notifications.isNullOrEmpty() && detailsKey != app.key
                        ) {
                            NotificationPreview(
                                notifications = notifications,
                                hideContent = hideContent,
                                onDismiss = { notificationRepository.cancelNotification(it) },
                                onMute = { vm.muteApp(pkg) },
                            )
                        }
                    }
                }
            }
            AlphabetIndex(
                letters = letters,
                selected = activeLetter,
                onSelect = { selectedLetter = it },
                modifier = Modifier.padding(end = 4.dp),
            )
        }
    }
}
