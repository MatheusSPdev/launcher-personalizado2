package de.mm20.launcher2.ui.launcher.search.alphabetic

import androidx.lifecycle.ViewModel
import de.mm20.launcher2.preferences.ui.AlphabeticHomeSettings
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

class AlphabeticHomeVM : ViewModel(), KoinComponent {
    private val settings: AlphabeticHomeSettings by inject()

    val enabled = settings.enabled
    val sidebarExpanded = settings.sidebarExpanded
    val wordOfTheDay = settings.wordOfTheDay
    val notifications = settings.notifications
    val hideNotificationContent = settings.hideNotificationContent
    val mutedApps = settings.mutedNotificationApps

    fun setSidebarExpanded(expanded: Boolean) = settings.setSidebarExpanded(expanded)
    fun muteApp(packageName: String) = settings.setNotificationsMuted(packageName, true)
    fun restoreMutedApps() = settings.clearMutedNotificationApps()
}
