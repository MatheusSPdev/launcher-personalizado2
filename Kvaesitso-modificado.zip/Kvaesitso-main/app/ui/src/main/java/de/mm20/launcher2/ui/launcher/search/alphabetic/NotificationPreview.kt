package de.mm20.launcher2.ui.launcher.search.alphabetic

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import de.mm20.launcher2.notifications.Notification
import de.mm20.launcher2.ui.R

/** Prévia da notificação mais recente do app, exibida abaixo do item do aplicativo. */
@Composable
fun NotificationPreview(
    notifications: List<Notification>,
    hideContent: Boolean,
    onDismiss: (Notification) -> Unit,
    onMute: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val latest = notifications.maxByOrNull { it.postTime } ?: return
    val title = latest.extras.getCharSequence(android.app.Notification.EXTRA_TITLE)?.toString()
    val text = latest.extras.getCharSequence(android.app.Notification.EXTRA_TEXT)?.toString()

    Row(
        modifier = modifier.padding(start = 16.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Column(modifier = Modifier.weight(1f)) {
            if (hideContent) {
                Text(
                    text = stringResource(R.string.alphabetic_notification_hidden),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            } else {
                if (!title.isNullOrBlank()) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (!text.isNullOrBlank()) {
                    Text(
                        text = text,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        TextButton(onClick = onMute) {
            Text(stringResource(R.string.alphabetic_notification_mute), style = MaterialTheme.typography.labelSmall)
        }
        if (latest.isClearable) {
            TextButton(onClick = { onDismiss(latest) }) {
                Text("\u2715")
            }
        }
    }
}
